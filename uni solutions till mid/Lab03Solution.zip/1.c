#include<stdio.h>


int main(){

 float initialDeposit=0,interestRate=10.0;
 interestRate/=100;
 printf("Enter initial deposit amount= ");
 scanf("%f",&initialDeposit);
 if(initialDeposit > 0){
    initialDeposit+=(initialDeposit*interestRate);
    printf("Amount after 1 month = %.2f\n",initialDeposit);
 }
 else{
     printf("Invalid Deposit Input! \n");
}

 return 0;
}
