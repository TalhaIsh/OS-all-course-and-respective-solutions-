#include<stdlib.h>
#include<stdio.h>
#include<math.h>
#include<string.h>
void sum(int a,int b){
int s;
s=a+b;
printf("\n sum= %d",s);
}
void subtract(int a,int b){
int s;
s=a-b;
printf("\n subtract= %d",s);
}

void multiply(int a,int b){
int s;
s=a*b;
printf("\n Multiply= %d",s);
}

void divide(int a,int b){
int s;
s=a/b;
printf("\n Divide= %d",s);
}

void even(int a){
if(a % 2 == 0){
printf("\n Even Number \n");
}

}

void odd(int a){
if(a % 2 != 0){
printf("\n Odd Number \n");
}

}


int isPerfectSquare(int x)
{
    int s = sqrt(x);
    if(s*s == x)
        return 1;
    else
        return 0;
}
 
void fib(int a)
{
    // n is Fibonacci if one of 5*n*n + 4 or 5*n*n - 4 or both
    // is a perfect square
 
    if(isPerfectSquare(5*a*a + 4) || isPerfectSquare(5*a*a - 4))
        printf("Number %d is fibonacci ",a);
    else
        printf("Number %d is not fibonacci ",a);
}


void fact(int a)
{
unsigned long long factorial = 1;
    if (a < 0)
        printf("Error! Factorial of a negative number doesn't exist.");
    else
    {
        for(int i=1; i<=a; ++i)
        {
            factorial *= i;              
        }
        printf("Factorial of %d = %llu", a, factorial);
    }

}

void prime(int a){


    int flag = 0;

    for(int i = 2; i <= a/2; i++)
    {
        if(a%i == 0)
        {
            flag = 1;
            break;
        }
    }
    if (a == 1) 
    {
      printf("1 is neither a prime nor a composite number.");
    }
    else 
    {
        if (flag == 0)
          printf("%d is a prime number.", a);
        else
          printf("%d is not a prime number.", a);
    }
    
}
void square(int a)
{
printf("Square= %d",a*a);

}
void cube(int a)
{
printf("Square= %d",a*a*a);

}



int main(int argc,char ** argv)
{
	printf("Math.out Is Loaded \n");
	int a = atoi(argv[1]);
	int b = atoi(argv[2]);
if(strcmp(argv[3],"even")==0){
	even(a);
}
else
if(strcmp(argv[3],"odd")==0){
	odd(a);
}
else
if(strcmp(argv[3],"sum")==0){
	sum(a,b);
}
else
if(strcmp(argv[3],"subtract")==0){
	subtract(a,b);
}
else
if(strcmp(argv[3],"multiply")==0){
	multiply(a,b);
}
else
if(strcmp(argv[3],"divide")==0){
	divide(a,b);
}
else
if(strcmp(argv[3],"fib")==0){
	fib(a);
}
else
if(strcmp(argv[3],"fact")==0){
	fact(a);
}
else
if(strcmp(argv[3],"prime")==0){
	prime(a);
}
else
if(strcmp(argv[3],"square")==0){
	square(a);
}
else
if(strcmp(argv[3],"cube")==0){
	cube(a);
}


}
