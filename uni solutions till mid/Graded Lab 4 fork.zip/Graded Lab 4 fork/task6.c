#include<stdlib.h>
#include<stdio.h>
#include <unistd.h>
int main(int argc, char **argv)
{
	int number = atoi(argv[1]);
	printf("The Number Entered Is %d \n",number);
	execv("math.out",argv);

}
